package proj.concert.service.mapper;

import proj.concert.common.dto.ConcertDTO;
import proj.concert.common.dto.ConcertSummaryDTO;
import proj.concert.service.domain.Concert;
import proj.concert.service.domain.Performer;

import java.util.ArrayList;
import java.util.List;

public class ConcertMapper {

    public static ConcertDTO toConcertDTO(Concert c) {
        ConcertDTO concertDTO = new ConcertDTO(c.getId(), c.getTitle(), c.getImageName(), c.getBlurb());
        for (Performer performer : c.getPerformers()) {
            concertDTO.getPerformers().add(PerformerMapper.toDTO(performer));
        }
        concertDTO.getDates().addAll(c.getDates());
        return concertDTO;
    }


    public static List<ConcertDTO> listToDTO(List<Concert> concerts) {
        List<ConcertDTO> concertDTOList = new ArrayList<>();
        for (Concert c : concerts) {
            concertDTOList.add(ConcertMapper.toConcertDTO(c));
        }
        return concertDTOList;
    }

    public static List<ConcertSummaryDTO> listToConcertSummaryDTO(List<Concert> concerts) {
        List<ConcertSummaryDTO> concertSummaryDTOS = new ArrayList<>();
        for (Concert c : concerts) {
            concertSummaryDTOS.add(new ConcertSummaryDTO(c.getId(), c.getTitle(), c.getImageName()));
        }
        return concertSummaryDTOS;
    }
}