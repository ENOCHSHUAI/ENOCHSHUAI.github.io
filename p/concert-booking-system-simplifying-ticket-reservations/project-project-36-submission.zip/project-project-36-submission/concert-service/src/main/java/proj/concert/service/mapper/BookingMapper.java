package proj.concert.service.mapper;

import proj.concert.common.dto.BookingDTO;
import proj.concert.service.domain.Booking;

import java.util.List;
import java.util.stream.Collectors;

public class BookingMapper {

    // Method to convert a Booking entity to a BookingDTO
    public static BookingDTO toDTO(Booking booking) {
        return new BookingDTO(
                booking.getConcertId(),
                booking.getDate(),
                booking.getSeats().stream()
                        .map(SeatMapper::toDTO)
                        .collect(Collectors.toList())
        );
    }

    // Method to convert a list of Booking entities to a list of BookingDTOs
    public static List<BookingDTO> listToDTO(List<Booking> bookingList) {
        return bookingList.stream()
                .map(BookingMapper::toDTO)
                .collect(Collectors.toList());
    }
}
