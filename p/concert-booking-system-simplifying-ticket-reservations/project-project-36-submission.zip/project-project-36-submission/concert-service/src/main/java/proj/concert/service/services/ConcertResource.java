package proj.concert.service.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import proj.concert.common.dto.*;
import proj.concert.common.types.BookingStatus;
import proj.concert.service.domain.Booking;
import proj.concert.service.domain.Concert;
import proj.concert.service.domain.Performer;
import proj.concert.service.domain.Seat;
import proj.concert.service.jaxrs.LocalDateTimeParam;
import proj.concert.service.mapper.BookingMapper;
import proj.concert.service.mapper.ConcertMapper;
import proj.concert.service.mapper.PerformerMapper;
import proj.concert.service.mapper.SeatMapper;
import proj.concert.service.util.TheatreLayout;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.*;
import java.net.URI;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import proj.concert.service.domain.*;

@Path("/concert-service")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ConcertResource {

    // TODO Implement this.
    private static final Logger LOGGER = LoggerFactory.getLogger(ConcertResource.class);
    private static final List<Subscription> subscriptions = new ArrayList<>();

    // Concert
    //GetSingleConcert
    @GET
    @Path("/concerts/{id}")
    public Response getConcertById(@PathParam("id") long id) {
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            Concert concert = em.find(Concert.class, id);
            if (concert == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            ConcertDTO concertDTO = ConcertMapper.toConcertDTO(concert);
            return Response.ok(concertDTO).build();
        } finally {
            em.close();
        }
    }

    //testGetAllConcerts
    @GET
    @Path("/concerts")
    public Response getAllConcerts() {
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            List<Concert> concertList = em.createQuery("select c from Concert c", Concert.class).getResultList();
            List<ConcertDTO> concertDTOList = ConcertMapper.listToDTO(concertList);
            GenericEntity<List<ConcertDTO>> entity = new GenericEntity<>(concertDTOList) {
            };
            return Response.ok(entity).build();
        } finally {
            em.close();
        }
    }

    @GET
    @Path("concerts/summaries")
    public Response getConcertSummaries() {
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            List<Concert> concerts = em.createQuery("select c from Concert c", Concert.class).getResultList();
            List<ConcertSummaryDTO> concertSummaryDTOList = ConcertMapper.listToConcertSummaryDTO(concerts);
            GenericEntity<List<ConcertSummaryDTO>> entity = new GenericEntity<>(concertSummaryDTOList) {
            };
            return Response.ok(entity).build();
        } finally {
            em.close();
        }
    }

    //login
    @POST
    @Path("/login")
    public Response loginUser(UserDTO userDTO) {
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class).setParameter("username", userDTO.getUsername());
            User user = query.getResultStream().findFirst().orElse(null);
            if (user == null || !user.getPassword().equals(userDTO.getPassword())) {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }
            String token = UUID.randomUUID().toString();
            user.setCookie(token);
            em.getTransaction().begin();
            em.merge(user);
            em.getTransaction().commit();
            NewCookie authCookie = new NewCookie("auth", token);
            return Response.ok().cookie(authCookie).build();
        } finally {
            em.close();
        }
    }

    //Performer
    //getPerByID
    @GET
    @Path("/performers/{id}")
    public Response getPerformer(@PathParam("id") long id) {
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            Performer performer = em.find(Performer.class, id);
            if (performer == null) {
                return Response.status(Response.Status.NOT_FOUND).build();
            }
            PerformerDTO performerDTO = PerformerMapper.toDTO(performer);
            return Response.ok(performerDTO).build();
        } finally {
            em.close();
        }
    }

    //getAllPerformers
    @GET
    @Path("/performers")
    public Response getPerformers() {
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            List<Performer> performers = em.createQuery("SELECT p FROM Performer p", Performer.class).getResultList();
            List<PerformerDTO> performerDTOs = performers.stream()
                    .map(PerformerMapper::toDTO)
                    .collect(Collectors.toList());
            return Response.ok(performerDTOs).build();
        } finally {
            em.close();
        }
    }

    // Seats
    @GET
    @Path("seats/{date}")
    public Response getSeats(@PathParam("date") String dateTimeParam, @DefaultValue("Any") @QueryParam("status") BookingStatus bookingStatus) {
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            LocalDateTime dateTime = new LocalDateTimeParam(dateTimeParam).getLocalDateTime();
            String query = "select s from Seat s where s.date = :date";
            if (bookingStatus != BookingStatus.Any) {
                query += " and s.isBooked = :status";
            }
            TypedQuery<Seat> seatQuery = em.createQuery(query, Seat.class).setParameter("date", dateTime);
            if (bookingStatus != BookingStatus.Any) {
                boolean isBooked = (bookingStatus == BookingStatus.Booked);
                seatQuery.setParameter("status", isBooked);
            }
            List<SeatDTO> dtos = seatQuery.getResultList().stream().map(SeatMapper::toDTO).collect(Collectors.toList());
            GenericEntity<List<SeatDTO>> entity = new GenericEntity<>(dtos) {};
            return Response.ok(entity).build();
        }finally {
            em.close();
        }
    }

    // Subscribe
    @POST
    @Path("/subscribe/concertInfo")
    public void subscribeConcertInfo(ConcertInfoSubscriptionDTO subscriptionDTO, @CookieParam("auth") Cookie cookie, @Suspended AsyncResponse sub){
        if (cookie == null) {
            sub.resume(Response.status(Response.Status.UNAUTHORIZED).build());
        }
        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            Concert concert = em.find(Concert.class, subscriptionDTO.getConcertId());
            if (concert == null) {
                sub.resume(Response.status(Response.Status.BAD_REQUEST).build());
            }
            if (!concert.getDates().contains(subscriptionDTO.getDate())) {
                sub.resume(Response.status(Response.Status.BAD_REQUEST).build());
            }
            List<Booking> allmatchedBookings = em.createQuery("select b from Booking b join fetch b.seats where b.concertId = : id and b.date = :date", Booking.class)
                    .setParameter("id", subscriptionDTO.getConcertId())
                    .setParameter("date", subscriptionDTO.getDate())
                    .getResultList();
            List<Seat> allmatchedSeats = new ArrayList<>();
            for (Booking b : allmatchedBookings) {
                allmatchedSeats.addAll(b.getSeats());
            }
            if (subscriptionDTO.getPercentageBooked() < (allmatchedSeats.size() / TheatreLayout.NUM_SEATS_IN_THEATRE) * 100) {
                ConcertInfoNotificationDTO infoDto = new ConcertInfoNotificationDTO(TheatreLayout.NUM_SEATS_IN_THEATRE - allmatchedSeats.size());
                sub.resume(Response.ok(infoDto).build());
                return;
            }
            subscriptions.add(new Subscription(subscriptionDTO, sub));
        } finally {
            em.close();
        }
    }

    // Functions

    private static class Subscription {
        ConcertInfoSubscriptionDTO subDto;
        AsyncResponse response;

        public Subscription(ConcertInfoSubscriptionDTO subDto, AsyncResponse response) {
            this.subDto = subDto;
            this.response = response;
        }

        public ConcertInfoSubscriptionDTO getSubDto() {
            return subDto;
        }

        public AsyncResponse getResponse() {
            return response;
        }
    }

    //makebooking
    @POST
    @Path("/bookings")
    public Response makeBooking(BookingRequestDTO bookingRequestDTO, @CookieParam("auth") Cookie authCookie) {
        if (authCookie == null) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }

        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            em.getTransaction().begin();

            User user = getUserFromCookie(em, authCookie);
            if (user == null) {
                return Response.status(Response.Status.UNAUTHORIZED).build();
            }

            Concert concert = getConcert(em, bookingRequestDTO.getConcertId());
            if (concert == null || !concert.getDates().contains(bookingRequestDTO.getDate())) {
                return Response.status(Response.Status.BAD_REQUEST).build();
            }

            List<Seat> seats = getAvailableSeats(em, bookingRequestDTO);
            if (seats.size() != bookingRequestDTO.getSeatLabels().size()) {
                return Response.status(Response.Status.FORBIDDEN).build();
            }

            Booking newBooking = createBooking(user, bookingRequestDTO, seats);
            em.persist(newBooking);
            em.getTransaction().commit();

            processSubscriptions(bookingRequestDTO, em);

            return Response.created(URI.create("concert-service/bookings/" + newBooking.getId()))
                    .cookie(new NewCookie("auth", authCookie.getValue()))
                    .build();

        } finally {
            em.close();
        }
    }

    private User getUserFromCookie(EntityManager em, Cookie authCookie) {
        return authUserWithCookie(em, authCookie);
    }

    private Concert getConcert(EntityManager em, Long concertId) {
        return em.find(Concert.class, concertId);
    }

    private List<Seat> getAvailableSeats(EntityManager em, BookingRequestDTO bookingRequestDTO) {
        String query = "SELECT s FROM Seat s WHERE s.isBooked = false AND s.date = :date AND s.label IN :labels";
        return em.createQuery(query, Seat.class)
                .setLockMode(LockModeType.OPTIMISTIC)
                .setParameter("date", bookingRequestDTO.getDate())
                .setParameter("labels", bookingRequestDTO.getSeatLabels())
                .getResultList();
    }

    private Booking createBooking(User user, BookingRequestDTO bookingRequestDTO, List<Seat> seats) {
        Booking newBooking = new Booking(user, bookingRequestDTO.getConcertId(), bookingRequestDTO.getDate());
        for (Seat seat : seats) {
            seat.setBooked(true);
            newBooking.getSeats().add(seat);
        }
        return newBooking;
    }

    private void processSubscriptions(BookingRequestDTO bookingRequestDTO, EntityManager em) {
        List<Seat> bookedSeatsList = em.createQuery("SELECT s FROM Seat s WHERE s.date = :date AND s.isBooked = true", Seat.class)
                .setParameter("date", bookingRequestDTO.getDate())
                .getResultList();

        if (!subscriptions.isEmpty()) {
            List<Subscription> relevantSubscriptions = subscriptions.stream()
                    .filter(sub -> sub.getSubDto().getConcertId() == bookingRequestDTO.getConcertId()
                            && sub.getSubDto().getDate().equals(bookingRequestDTO.getDate())
                            && sub.getSubDto().getPercentageBooked() < ((100 * bookedSeatsList.size()) / TheatreLayout.NUM_SEATS_IN_THEATRE))
                    .collect(Collectors.toList());

            int remainingSeats = TheatreLayout.NUM_SEATS_IN_THEATRE - bookedSeatsList.size();

            synchronized (subscriptions) {
                for (Subscription sub : relevantSubscriptions) {
                    ConcertInfoNotificationDTO dto = new ConcertInfoNotificationDTO(remainingSeats);
                    sub.getResponse().resume(Response.ok(dto).build());
                    subscriptions.remove(sub);
                }
            }
        }
    }

    @GET
    @Path("/bookings/{id}")
    public Response getBooking(@PathParam("id") long id, @CookieParam("auth") Cookie authCookie) {
        if (authCookie == null) {
            return Response.status(Response.Status.UNAUTHORIZED).entity("Authentication cookie is missing").build();
        }

        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            User user = getAuthenticatedUser(em, authCookie);
            if (user == null) {
                return Response.status(Response.Status.UNAUTHORIZED).entity("User authentication failed").build();
            }
            Booking booking = getBookingById(em, id);
            if (booking == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Booking not found").build();
            }

            if (!isUserAuthorized(user, booking)) {
                return Response.status(Response.Status.FORBIDDEN).entity("User is not authorized to access this booking").build();
            }

            BookingDTO bookingDTO = BookingMapper.toDTO(booking);
            NewCookie responseCookie = new NewCookie("auth", authCookie.getValue());
            return Response.ok(bookingDTO).cookie(responseCookie).build();

        } finally {
            em.close();
        }
    }

    private Booking getBookingById(EntityManager em, long id) {
        return em.find(Booking.class, id);
    }

    private boolean isUserAuthorized(User user, Booking booking) {
        return booking.getUser().equals(user);
    }


    @GET
    @Path("/bookings")
    public Response getAllBooking(@CookieParam("auth") Cookie authCookie) {
        if (authCookie == null) {
            return Response.status(Response.Status.UNAUTHORIZED).entity("Missing authentication cookie").build();
        }

        EntityManager em = PersistenceManager.instance().createEntityManager();
        try {
            User user = getAuthenticatedUser(em, authCookie);
            if (user == null) {
                return Response.status(Response.Status.UNAUTHORIZED).entity("Invalid user").build();
            }

            List<Booking> bookings = getUserBookings(em, user);
            List<BookingDTO> bookingsDTO = BookingMapper.listToDTO(bookings);

            return Response.ok(new GenericEntity<>(bookingsDTO) {})
                    .cookie(new NewCookie("auth", authCookie.getValue()))
                    .build();
        } finally {
            em.close();
        }
    }

    // Helper method to authenticate the user
    private User getAuthenticatedUser(EntityManager em, Cookie authCookie) {
        return authUserWithCookie(em, authCookie);
    }

    // Helper method to retrieve the user's bookings
    private List<Booking> getUserBookings(EntityManager em, User user) {
        String query = "SELECT booking FROM Booking booking WHERE booking.user = :user";
        return em.createQuery(query, Booking.class)
                .setParameter("user", user)
                .getResultList();
    }


    private User authUserWithCookie(EntityManager em, Cookie cookie) {
        return em.createQuery("SELECT user FROM User user WHERE user.cookie = :cookie", User.class)
                .setParameter("cookie", cookie.getValue())
                .getResultStream()
                .findFirst()
                .orElse(null);
    }
}