package proj.concert.service.domain;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "BOOKING")
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User user;

    private long concertId;
    private LocalDateTime date;

    @OneToMany
    private List<Seat> seats = new ArrayList<>();

    public Booking() {
    }

    public Booking(User user, long concertId, LocalDateTime date) {
        this.user = user;
        this.concertId = concertId;
        this.date = date;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public long getConcertId() {
        return concertId;
    }

    public void setConcertId(long concertId) {
        this.concertId = concertId;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public void setSeats(List<Seat> seats) {
        this.seats = seats;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Booking booking = (Booking) o;
        return concertId == booking.concertId && Objects.equals(id, booking.id) && Objects.equals(user, booking.user) && Objects.equals(date, booking.date) && Objects.equals(seats, booking.seats);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, user, concertId, date, seats);
    }
}
