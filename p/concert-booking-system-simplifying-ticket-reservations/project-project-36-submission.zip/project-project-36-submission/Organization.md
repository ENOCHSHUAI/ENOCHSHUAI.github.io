## Domain Model
- **Concert**：Represents a concert, which includes multiple performers and seats.
- **Performer**：Represents the artists for a concert.
- **User**：the user, can make booking concerts.
- **Reservation**：user's booking, one user can book multiple seats.
- **Seat**：seats information, eg.is booked or not.


## Domain Model: Write together in lab, push by YueJoyLyu.
## DTO: Write together in lab,push by YueJoyLyu
## ConcertResource: Collaboratively written.
- YueJoyLyu (ylyu135): Responsible for writing the login and Concert classes.
- JunxiaoChen (jehc362): Responsible for writing the booking class(We all agree that booking is more complex, so one person will mainly handle it.)
- EnochSun (ysun344): Responsible for writing the Seats, Performer, and Subscribe classes(we discussed together for Subscribe, and write by EnochSun).
