import {Modal} from "./modal.js";

window.addEventListener("load", Modal.enableModalsOnPage);